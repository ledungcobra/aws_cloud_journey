const http = require("http");

const hostname = "127.0.0.1";
const port = 8081;

const net = require("net");

const server = net.createServer((socket) => {
  socket.write("Hello world from 8081");
  socket.on("data", (data) => {
    console.log("Received: " + data);
  });

  socket.on("close", () => {
    console.log("Connection closed");
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
