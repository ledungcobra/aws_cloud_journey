docker build -t ipc-app1 app1
docker build -t ipc-app2 app2

# Apply the pod configuration to the cluster
kubectl apply -f pod.yaml

# Get the pod status
kubectl get pods

# Troubleshooting
kubectl describe pod ipc-pod

# Get the pod logs
kubectl logs ipc-pod -c ipc-app1
kubectl logs ipc-pod -c ipc-app2

# Clean up resources
kubectl delete pod ipc-pod


# Port forwarding to testing local

kubectl port-forward ipc-pod 8080:8080

# Test the connection
curl http://localhost:8080

